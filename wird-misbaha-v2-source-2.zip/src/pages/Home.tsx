import { useEffect, useMemo, useState } from 'react'
import { Activity, BarChart3, BookOpen, Check, ChevronLeft, CircleHelp, Hand, Heart, History, Leaf, Moon, Settings2, Sparkles, Target, Timer, TrendingUp } from 'lucide-react'
import AmbientWave from '@/sections/AmbientWave'
import DhikrCounter from '@/sections/DhikrCounter'
import JourneyChart from '@/sections/JourneyChart'
import Extras from '@/sections/Extras'
import Affirm from '@/sections/Affirm'
import Survey from '@/sections/Survey'
import Insights from '@/sections/Insights'
import StatePanel from '@/sections/StatePanel'
import { load, save, stats } from '@/lib/store'
import { arNum } from '@/lib/model'
import { useDhikrSession } from '@/hooks/useDhikrSession'

type Tab = 'home' | 'journey' | 'insights' | 'stats' | 'survey' | 'settings' | 'about'
const nav: { id: Tab; label: string; icon: typeof Hand }[] = [
  { id: 'home', label: 'المسبحة', icon: Hand },
  { id: 'journey', label: 'رحلتي', icon: TrendingUp },
  { id: 'insights', label: 'التحليل', icon: Activity },
  { id: 'stats', label: 'الإحصاءات', icon: BarChart3 },
  { id: 'survey', label: 'حالتي', icon: Heart },
  { id: 'settings', label: 'الإعدادات', icon: Settings2 },
]

function Mark() {
  return <div className="brand-mark"><svg viewBox="0 0 64 64" aria-hidden="true"><path d="M32 5 39 20 55 13 48 29 61 36 44 41 48 58 32 48 16 58 20 41 3 36 16 29 9 13 25 20Z"/><circle cx="32" cy="32" r="10"/><circle cx="32" cy="32" r="3"/></svg></div>
}

export default function Home() {
  const s = useDhikrSession()
  const [tab, setTab] = useState<Tab>('home')
  const [quiet, setQuiet] = useState(() => load('quiet', false))
  const [showWelcome, setShowWelcome] = useState(() => !load('welcomed', false))
  const [todayGoal, setTodayGoal] = useState(() => load('dailyGoal', 100))
  const today = useMemo(() => stats(s.sessions, 1), [s.sessions])
  const totalToday = useMemo(() => s.sessions.filter(x => new Date(x.ts).toDateString() === new Date().toDateString()).reduce((n, x) => n + x.count, 0) + s.total, [s.sessions, s.total])
  const progress = Math.min(100, Math.round(totalToday / Math.max(1, todayGoal) * 100))
  useEffect(() => { document.documentElement.dataset.theme = load('theme', ''); document.documentElement.dataset.quiet = String(quiet) }, [quiet])
  const chooseTab = (id: Tab) => { setTab(id); window.scrollTo({ top: 0, behavior: 'smooth' }) }

  return <div className="app-shell" dir="rtl">
    <AmbientWave getElapsed={s.getElapsed} pulse={s.pulse} />
    <div className="ambient-grid" aria-hidden="true" />
    <header className="topbar">
      <button className="brand" onClick={() => chooseTab('home')} aria-label="العودة للرئيسية"><Mark/><span><b>وِرد</b><small>رفيق الذكر اليومي</small></span></button>
      <div className="top-actions"><span className="soft-status"><span className="status-dot"/> مساحة هادئة لك</span><button className="icon-button" aria-label={quiet ? 'إيقاف وضع الهدوء' : 'تفعيل وضع الهدوء'} title={quiet ? 'وضع الهدوء مفعّل' : 'وضع الهدوء'} onClick={() => { const n = !quiet; setQuiet(n); save('quiet', n) }}>{quiet ? <Moon size={18}/> : <Sparkles size={18}/>}</button></div>
    </header>

    <main className="main-content">
      {tab === 'home' && <>
        <section className="welcome-row">
          <div><p className="eyebrow"><Sparkles size={14}/> لحظة لك ولذكر الله</p><h1>طمئن قلبك، <span>واذكر ربك.</span></h1><p className="subhead">لا تحتاج إلى وقتٍ مثالي؛ ابدأ بالذكر الذي تستطيع، ومن حيث أنت.</p></div>
          <div className="verse-card"><span className="verse-ornament">۞</span><p>أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ</p><small>الرعد · ٢٨</small></div>
        </section>
        {showWelcome && <div className="welcome-note"><div className="note-icon"><Leaf size={19}/></div><div><b>ابدأ على مهل</b><p>اجعل هدفك معينًا لك لا عبئًا عليك. يمكنك تغيير هدفك متى شئت، ولا تُقاس قيمة الذكر بعدد النقرات وحده.</p></div><button onClick={() => { setShowWelcome(false); save('welcomed', true) }} aria-label="إغلاق"><Check size={18}/></button></div>}
        <div className="home-grid">
          <section className="panel counter-panel"><div className="panel-heading"><div><span className="section-kicker">مساحة التسبيح</span><h2>على مهلٍ… ذكرًا ذكرًا</h2></div><span className="live-pill"><span/> مباشر</span></div>
            <DhikrCounter dhikr={s.dhikr} count={s.count} rounds={s.rounds} onTap={s.tap} onSelect={s.selectDhikr} adhkar={s.adhkar} onTarget={(n) => s.setTarget(s.dhikr.id, n)}/>
            <div className="counter-footer"><span><Target size={15}/> هدف الذكر: {arNum(s.dhikr.target)}</span><span>يمكنك التراجع عن النقرة الخاطئة من التحليل</span></div>
          </section>
          <aside className="side-stack">
            <section className="panel session-panel"><div className="panel-heading"><div><span className="section-kicker">جلسة الذكر</span><h2>حضور بلا استعجال</h2></div><div className="mini-icon"><Timer size={18}/></div></div><StatePanel elapsedSec={s.elapsedSec} running={s.running} total={s.total} onStart={s.start} onPause={s.pause} onReset={s.reset}/></section>
            <section className="panel daily-panel"><div className="daily-head"><div><span className="section-kicker">وِرد اليوم</span><h2>خطوات صغيرة، أثر طيب</h2></div><div className="mini-icon"><BookOpen size={18}/></div></div><div className="daily-numbers"><strong>{arNum(totalToday)}</strong><span>/ {arNum(todayGoal)} تسبيحة</span><b>{arNum(progress)}٪</b></div><div className="progress-track"><span style={{width: `${progress}%`}}/></div><div className="goal-edit"><span>{progress >= 100 ? 'أحسنت، أنجزت هدفك اليوم.' : 'اختر هدفًا يناسب يومك.'}</span><select aria-label="الهدف اليومي" value={todayGoal} onChange={e => { const n = +e.target.value; setTodayGoal(n); save('dailyGoal', n) }}><option value={33}>٣٣</option><option value={100}>١٠٠</option><option value={300}>٣٠٠</option><option value={500}>٥٠٠</option></select></div><p className="gentle-note">إن فاتك يوم، فابدأ من جديد برفق؛ لا توجد سلسلة تستحق أن تثقل قلبك.</p></section>
          </aside>
        </div>
        <section className="affirm-wrap"><Affirm/></section>
        <section className="bottom-prompt"><div className="prompt-symbol"><Moon size={21}/></div><div><b>ليس السباق إلى الرقم، بل صدق التوجّه.</b><p>خذ لحظة لتستحضر معنى الذكر، ثم واصل بما يطمئنك.</p></div><button onClick={() => chooseTab('survey')}>تفقّد حالتي <ChevronLeft size={16}/></button></section>
      </>}
      {tab === 'journey' && <PageIntro icon={TrendingUp} title="رحلتي مع الذكر" desc="نظرة لطيفة إلى جلساتك وتقدّمك، دون مقارنة نفسك بأحد."/>}
      {tab === 'journey' && <section className="panel chart-panel"><JourneyChart elapsedSec={s.elapsedSec} trace={s.trace}/><p className="disclaimer">المنحنيات في هذا التطبيق تصوّر افتراضي للتأمل في الجلسة، وليست قياسًا لنشاط الدماغ أو نتيجةً طبية مؤكدة.</p></section>}
      {tab === 'insights' && <><PageIntro icon={Activity} title="تفاصيل الجلسة" desc="معلومات تساعدك على ملاحظة عاداتك، وليست تقييمًا إيمانيًا أو طبيًا."/><section className="panel content-panel"><Insights trace={s.trace} elapsedSec={s.elapsedSec} rhythm={s.rhythm} total={s.total} goal={s.goal} sessions={s.sessions} adhkar={s.adhkar} onUndo={s.undo} onManual={s.addManual}/></section></>}
      {tab === 'stats' && <><PageIntro icon={BarChart3} title="أثر الاستمرار" desc="راجع وقتك وجلساتك بالطريقة التي تناسبك."/><section className="stats-summary"><div className="metric-card"><span>جلسات محفوظة</span><b>{arNum(s.sessions.length)}</b><small><History size={14}/> في سجلّك</small></div><div className="metric-card"><span>وقت الذكر اليوم</span><b>{arNum(Math.round(today.min + s.elapsedSec / 60), 1)} <i>د</i></b><small><Timer size={14}/> وقت مسجّل</small></div><div className="metric-card"><span>أذكار اليوم</span><b>{arNum(totalToday)}</b><small><Hand size={14}/> مجموع تقريبي</small></div></section><section className="panel content-panel"><Extras adhkar={s.adhkar} sessions={s.sessions} goal={s.goal} onGoal={s.setGoal} onAdd={s.addCustom} onCap={() => {}} view="stats"/></section></>}
      {tab === 'survey' && <><PageIntro icon={Heart} title="كيف حال قلبك اليوم؟" desc="تدوين اختياري يساعدك على ملاحظة ما تحتاجه، وتبقى بياناتك على جهازك."/><section className="panel content-panel"><Survey/></section></>}
      {tab === 'settings' && <><PageIntro icon={Settings2} title="مساحتك، كما تحبّها" desc="خصص تجربتك وأهدافك وأضف الأذكار التي تودّ المواظبة عليها."/><section className="panel content-panel"><Extras adhkar={s.adhkar} sessions={s.sessions} goal={s.goal} onGoal={s.setGoal} onAdd={s.addCustom} onCap={() => {}} view="settings"/></section><section className="panel privacy-card"><div className="mini-icon"><Heart size={18}/></div><div><b>خصوصيتك وراحتك أولًا</b><p>تُحفظ بياناتك محليًا على هذا الجهاز. لا تُستخدم الأهداف أو الإحصاءات للحكم على تدينك، ويمكنك التوقف متى احتجت.</p></div></section></>}
      {tab === 'about' && <><PageIntro icon={CircleHelp} title="عن وِرد" desc="مسبحة رقمية هادئة صُممت لتسهيل الذكر اليومي."/><section className="panel about-card"><Mark/><h2>وِرد — رفيق الذكر اليومي</h2><p>مساحة تجمع عدّاد التسبيح، والأهداف الشخصية، وسجل الجلسات، والتأمل في العادات. الذكر عبادة، أما الأرقام فهي أدوات مساعدة لا أكثر.</p><div className="about-points"><span><Check size={16}/> عدّاد قابل للتخصيص</span><span><Check size={16}/> سجل محلي للجلسات</span><span><Check size={16}/> أهداف مرنة بلا ضغط</span></div></section></>}
    </main>
    <nav className="bottom-nav" aria-label="التنقل الرئيسي">{nav.map(({id,label,icon:Icon}) => <button key={id} className={tab === id ? 'nav-item active' : 'nav-item'} onClick={() => chooseTab(id)}><Icon size={19} strokeWidth={tab === id ? 2.2 : 1.7}/><span>{label}</span></button>)}<button className={tab === 'about' ? 'nav-item active' : 'nav-item'} onClick={() => chooseTab('about')}><CircleHelp size={19}/><span>عن التطبيق</span></button></nav>
    <footer className="app-footer"><span>صُنع ليكون الذكر أقرب</span><span>وِرد <b>✦</b></span></footer>
  </div>
}

function PageIntro({icon: Icon, title, desc}: {icon: typeof Hand; title: string; desc: string}) {
  return <section className="page-intro"><div className="intro-icon"><Icon size={22}/></div><div><p className="eyebrow">مساحتك الشخصية</p><h1>{title}</h1><p className="subhead">{desc}</p></div></section>
}
